# Snowmoon 中文译本 · 源文本

原作：Vitalik Buterin，https://vitalik.eth.limo/snowmoon/ ，GPL v3。
本译本为修改版本（翻译），修改日期 2026-09-27，同样以 GPL v3 发布。

- zh/：各章中文 markdown（段落与英文原文一一对应）
- extras_zh/：聊天记录、设备屏幕、章首日期等特殊块（before = 插在第几段之前）
- build_site.py / build_pdf.py：生成网页版 / PDF
